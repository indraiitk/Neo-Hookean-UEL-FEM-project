%% Analytical response of the 2 x 2 plane-strain UEL patch
% Constitutive model implemented in UEL_Hyperelastic.for:
%   P = mu*(F - F^(-T)) + kappa*J*(J-1)*F^(-T)
%
% Boundary conditions represented here:
%   lambda1 = 1 + u_right/L
%   P22 = 0 (top and bottom are traction-free)
%   F12 = F21 = 0
%
% Consistent example units: N, mm, MPa.

clear;
clc;
close all;

%% Input data (same as square_patch_test_4el.inp)
mu       = 2.0;       % MPa
kappa    = 5.0;       % MPa
L        = 2.0;       % initial plate width, mm
u_max    = 0.2;       % prescribed right-edge displacement, mm
n_points = 201;

%% Prescribed horizontal stretch
u_right = linspace(0.0, u_max, n_points).';
lambda1 = 1.0 + u_right/L;

%% Traction-free transverse stretch
% P22 = 0 gives:
% (mu + kappa*lambda1^2)*lambda2^2
%       - kappa*lambda1*lambda2 - mu = 0.
% The positive root is the physical solution.
a = mu + kappa.*lambda1.^2;
b = -kappa.*lambda1;
c = -mu;
lambda2 = (-b + sqrt(b.^2 - 4.0.*a.*c))./(2.0.*a);

%% Deformation and stresses
J = lambda1.*lambda2;

% First Piola-Kirchhoff stress P11, useful for checking reactions.
P11 = mu.*(lambda1 - 1.0./lambda1) ...
    + kappa.*J.*(J - 1.0)./lambda1;

% Cauchy stress sigma = (1/J)*P*F^T.
sigma11 = (mu./J).*(lambda1.^2 - 1.0) + kappa.*(J - 1.0);
sigma22 = (mu./J).*(lambda2.^2 - 1.0) + kappa.*(J - 1.0);

%% Display and export results
results = table(u_right, lambda1, lambda2, J, P11, sigma11, sigma22);
disp(results(1:20:end, :));

fprintf('\nAt u_right = %.6g mm:\n', u_right(end));
fprintf('lambda1 = %.9f\n', lambda1(end));
fprintf('lambda2 = %.9f\n', lambda2(end));
fprintf('J       = %.9f\n', J(end));
fprintf('P11     = %.9f MPa\n', P11(end));
fprintf('sigma11 = %.9f MPa\n', sigma11(end));
fprintf('sigma22 = %.3e MPa (should be approximately zero)\n', sigma22(end));

writetable(results, 'analytical_patch_sigma11.csv');

%% Displacement versus Cauchy stress sigma_11
figure('Color', 'w');
plot(u_right, sigma11, 'b-', 'LineWidth', 2.0);
grid on;
box on;
xlabel('Right-edge displacement, u_1 (mm)');
ylabel('Cauchy stress, \sigma_{11} (MPa)');
title('Analytical response of 2 x 2 plane-strain patch');

