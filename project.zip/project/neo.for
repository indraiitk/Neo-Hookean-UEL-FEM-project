       module kvisual
       implicit none
       real*8 sigout(10000,4,4)
       save
       end module    

       SUBROUTINE UEL(RHS,AMATRX,SVARS,ENERGY,NDOFEL,NRHS,NSVARS,
     1 PROPS,NPROPS,COORDS,MCRD,NNODE,U,DU,V,A,JTYPE,TIME,DTIME,
     2 KSTEP,KINC,JELEM,PARAMS,NDLOAD,JDLTYP,ADLMAG,PREDEF,NPREDF,
     3 LFLAGS,MLVARX,DDLMAG,MDLOAD,PNEWDT,JPROPS,NJPROP,PERIOD)
C
      use kvisual
      INCLUDE 'ABA_PARAM.INC'
C	  
       dimension RHS(MLVARX,*),AMATRX(NDOFEL,NDOFEL),PROPS(*),
     1 SVARS(NSVARS),ENERGY(8),COORDS(MCRD,NNODE),U(NDOFEL),
     2 DU(MLVARX,*),V(NDOFEL),A(NDOFEL),TIME(2),PARAMS(*),
     3 JDLTYP(MDLOAD,*),ADLMAG(MDLOAD,*),DDLMAG(MDLOAD,*),
     4 PREDEF(2,NPREDF,NNODE),LFLAGS(*),JPROPS(*)

       PARAMETER (maxDOF=2, ndof=2, ndim=2 ,ngp=4, nelem=1, nsdv=4, nsvint=4, ntens=4)
       dimension dshape(ndim,4),xjac(maxDOF,maxDOF),xjaci(maxDOF,maxDOF),
     1 gmat(4,2*nnode),gmatT(2*nnode,4),kmat(2*nnode,2*nnode),DDmat(4,4),
     2 xeps(4),spk1_vec(4),sc_vec(4),SDV(4),statevLocal(nsvint),db2(8,8),
     3 F(2,2), Ft(2,2), Finv(2,2), spk1(2,2), dsdf(2,2,2,2), dmat(4,4), xId(2,2),
     4 scauchy(2,2) 
       
       dimension db(4,2*nnode),resgp(NDOFEL),tngp(NDOFEL,NDOFEL)

       rhs(:, 1)=0.d0
       amatrx=0.d0		
				
       resgp = 0.d0
       tngp = 0.d0
          
       DDmat=0.d0
       sc_vec = 0.d0
       spk1_vec = 0.d0
       spk1 = 0.d0
       scauchy = 0.d0
          
       F = 0.d0
       Ft = 0.d0
       Finv = 0.d0
		
       xmu = props(1)
       xgp = props(2)
       
        ! Start loop over Gauss points -------------------------------------

        do kintk = 1, ngp	 
        !
        ! Fetch shape functions from the following subroutine --------------
        ! 
        call shapeFunc(kintk,ngp,nnode,ndim,shapef,dshape)
	  !	
        ! Calculate isoparametric mapping Jacobian and inv(J) matrices -----
        djac = 1.d0        
        call jacobian(ndim,COORDS,nnode,djac,dshape,xjaci)
	  !
        ! Calculate [G] = [JI]*[NG] and [G]^T from the following subroutine- 
        !
        call Gmatrix(xjaci,dshape,nnode,ndim,gmat,gmatT)
        !
        ! Calculate [F], [F]^T, [F]^-1, det([F]) in the following ----------
        !
        call kftens(ntens,ndof,ndim,nnode,MLVARX,gmat,U,F,Ft,Finv,detF,xId)
        !
        !
        ! Calculate PK1 tensor and DSDF fourth order tensor for Neo-Hookean model
        !
          do i=1,2
              do j=1,2
                 spk1(i,j) = xmu*(F(i,j)-Finv(j,i))+
     1                       xgp*detF*(detF-1.0d0)*Finv(j,i)
                do k=1,2
                    do l=1,2
                        dsdf(i,j,k,l) = xmu*(xId(i,k)*xId(j,l) + 
     1                                  Finv(l,i)*Finv(j,k)) + 
     2                                  xgp*detF*(2.0d0*detF-1.0d0)*Finv(l,k)*Finv(j,i) -
     3                                  xgp*detF*(detF-1.0d0)*Finv(l,i)*Finv(j,k)     
                    end do
                end do
              end do
          end do
        !
        ! Form PK1 stress vector {S} needed for the residue vector calculation --
        !
        spk1_vec(1) = spk1(1,1)
        spk1_vec(2) = spk1(1,2)
        spk1_vec(3) = spk1(2,1)
        spk1_vec(4) = spk1(2,2)
        !
        ! Form D matrix with the elements of fourth order tensor DSDF -------------
        !
        DDmat(1,1) = dsdf(1,1,1,1)
        DDmat(1,2) = dsdf(1,1,1,2)
        DDmat(1,3) = dsdf(1,1,2,1)
        DDmat(1,4) = dsdf(1,1,2,2)
          
        DDmat(2,1) = dsdf(1,2,1,1)
        DDmat(2,2) = dsdf(1,2,1,2)
        DDmat(2,3) = dsdf(1,2,2,1)
        DDmat(2,4) = dsdf(1,2,2,2)
          
        DDmat(3,1) = dsdf(2,1,1,1)
        DDmat(3,2) = dsdf(2,1,1,2)
        DDmat(3,3) = dsdf(2,1,2,1)
        DDmat(3,4) = dsdf(2,1,2,2)
          
        DDmat(4,1) = dsdf(2,2,1,1)
        DDmat(4,2) = dsdf(2,2,1,2)
        DDmat(4,3) = dsdf(2,2,2,1)
        DDmat(4,4) = dsdf(2,2,2,2)
        !
        !
        ! Calculate Gauss point residue = |J|*[G]^T*{S} ----------------------------
        !
        resgp=matmul(gmatT,spk1_vec)
        resgp=resgp*djac
        !
        do k1=1,8			
            RHS(k1, 1) = RHS(k1, 1) - resgp(k1)			
        end do
        !
        !
        ! Calculate Gauss point tangent stiffness matrix = |J|*[G]^T*[D]*[G] -------
        !
        db = 0.0d0
        db2 = 0.0d0
        !
        db=matmul(DDmat,gmat)
        db2=matmul(gmatT,db)
        tngp = db2*djac
        !
        do i=1,8
            do j=1,8
                AMATRX(i,j) = AMATRX(i,j) + tngp(i,j)
            end do
        end do
        !
        ! Calculate the Cauchy stress as an outpur variable (optional) -------------
        !
        scauchy = matmul(spk1,Ft)
        scauchy = scauchy*(1.0d0/detF)
        !                      
        sc_vec(1) = scauchy(1,1)
        sc_vec(2) = scauchy(1,2)
        sc_vec(3) = scauchy(2,1)
        sc_vec(4) = scauchy(2,2)
	  !
        ! Write the Cauchy stress values in the global variable sigout -------------
        ! 'sigout' will be read by the 'umat' subroutine ---------------------------
        !
        do k1=1,nsdv
      	sigout(jelem,kintk,k1) = sc_vec(k1)
        end do         
       !
        end do       

      RETURN
      END
C	  
C	  
C	  
**************************************************************************************
** Calculate shape functions at a particular Gauss point *****************************
**************************************************************************************	
C
C      
		subroutine shapeFunc(kintk,ngp,nnode,ndim,shapef,dshape)
		
		include 'aba_param.inc'
		
		parameter (gaussCoord=0.577350269189626)
		dimension shapef(4),dshape(ndim,4),coord24(2,4)
		
		data coord24  /1. , 1. ,
	2				  -1. , 1. ,
	3				   1. , -1.,
	4                  -1. , -1./
			
		shapef=0.
		dshape=0.
		xxi=coord24(1,kintk)*gaussCoord
		xet=coord24(2,kintk)*gaussCoord
		
		! shape functions
		
		shapef(1)=0.25*(1.+xxi)*(1.+xet)
		shapef(2)=0.25*(1.-xxi)*(1.+xet)
          shapef(3)=0.25*(1.-xxi)*(1.-xet)
          shapef(4)=0.25*(1.+xxi)*(1.-xet)
	
		! derivation to xi
		
		dshape(1,1)=0.25*(1.+xet)
		dshape(1,2)=-0.25*(1.+xet)
          dshape(1,3)=-0.25*(1.-xet)
          dshape(1,4)=0.25*(1.-xet)	
	
	
	    ! derivation to s
		
		dshape(2,1)=0.25*(1.+xxi)
		dshape(2,2)=0.25*(1.-xxi)
          dshape(2,3)=-0.25*(1.-xxi)
          dshape(2,4)=-0.25*(1.+xxi)
	
		return
          end
C		
C
**************************************************************************************
** Calculate Jacobian matrix for isoparametric mapping *******************************
**************************************************************************************
C
C      
		subroutine jacobian(ndim,coords,nnode,djac,dshape,xjaci)
		
		include 'aba_param.inc'
		
		dimension xjac(ndim,ndim),xjaci(ndim,ndim)
		dimension coords(2,nnode),dshape(ndim,nnode)

		xjac=0.d0
		xjaci=0.d0

		
          do inod= 1, nnode
            do kdim = 1, ndim
              do jdim = 1, ndim
                xjac(jdim,kdim) = xjac(jdim,kdim) + 
     1          dshape(jdim,inod)*coords(kdim,inod)      
              end do
            end do 
          end do
		
		
		djac=xjac(1,1)*xjac(2,2)-xjac(1,2)*xjac(2,1)
		 
		if (djac .gt. 0.) then
			xjaci(1,1)=xjac(2,2)/djac
			xjaci(2,2)=xjac(1,1)/djac
			xjaci(1,2)=-xjac(1,2)/djac
			xjaci(2,1)=-xjac(2,1)/djac			
		end if
		
		return
		end
C		
C
**************************************************************************************
** Calculate matrices [G] and [G]^T **************************************************
**************************************************************************************
C
C 
		subroutine Gmatrix(xjaci,dshape,nnode,ndim,gmat,gmatT)
		
		include 'aba_param.inc'
		
		dimension xjaci(ndim,ndim),dshape(ndim,4)
		dimension gmat(4,2*nnode),gmatT(2*nnode,4)
          dimension xjimat(4,4),xngmat(4,2*nnode)

          gmat=0.d0
          gmatT=0.d0
          xjimat=0.d0
          xngmat=0.d0

          xjimat(1,1)=xjaci(1,1)
          xjimat(1,2)=xjaci(1,2)
          xjimat(2,1)=xjaci(2,1)
          xjimat(2,2)=xjaci(2,2)
          !
          xjimat(3,3)=xjaci(1,1)
          xjimat(3,4)=xjaci(1,2)
          xjimat(4,3)=xjaci(2,1)
          xjimat(4,4)=xjaci(2,2)
				
          xngmat(1,1) = dshape(1,1)
          xngmat(1,3) = dshape(1,2)
          xngmat(1,5) = dshape(1,3)
          xngmat(1,7) = dshape(1,4)
          
          xngmat(2,1) = dshape(2,1)
          xngmat(2,3) = dshape(2,2)
          xngmat(2,5) = dshape(2,3)
          xngmat(2,7) = dshape(2,4)
          
          xngmat(3,2) = dshape(1,1)
          xngmat(3,4) = dshape(1,2)
          xngmat(3,6) = dshape(1,3)
          xngmat(3,8) = dshape(1,4)
          
          xngmat(4,2) = dshape(2,1)
          xngmat(4,4) = dshape(2,2)
          xngmat(4,6) = dshape(2,3)
          xngmat(4,8) = dshape(2,4)
          
          gmat = matmul(xjimat,xngmat)
		
		do i=1,4
			do j=1,2*nnode
				gmatT(j,i)=gmat(i,j)
			end do
          end do
		
		return
          end
		
      
C***********************************************************************************
C *********** Calculation of F, Finv, Ft, detF *************************************          
C***********************************************************************************
          
          
          subroutine kftens(ntens,ndof,ndim,nnode,MLVARX,gmat,U,F,Ft,Finv,detF,xId)
            
          include 'aba_param.inc'
          dimension gmat(4,2*nnode),u(mlvarx,1),gradu(4,1)
          dimension F(2,2), Ft(2,2), Finv(2,2), xId(2,2)
			
          F = 0.d0
          Ft = 0.d0
          Finv = 0.d0
          gradu=0.d0
          xId = 0.d0
            
          gradu=matmul(gmat,u)
            
          F(1,1) = 1.0d0 + gradu(1,1)
          F(1,2) = gradu(2,1)
          F(2,1) = gradu(3,1)
          F(2,2) = 1.0d0 + gradu(4,1)
                      
          Ft(1,1) = F(1,1)
          Ft(1,2) = F(2,1)
          Ft(2,1) = F(1,2)
          Ft(2,2) = F(2,2)
            
          detF = F(1,1)*F(2,2)-F(1,2)*F(2,1)
		 
          if (detF .gt. 0.) then
			 Finv(1,1) = F(2,2)/detF
			 Finv(2,2) = F(1,1)/detF
			 Finv(1,2) = -F(1,2)/detF
			 Finv(2,1) = -F(2,1)/detF			
          end if
            
          xId(1,1) = 1.0d0
          xId(2,2) = 1.0d0
            
          return
          end
      
C		
C
**************************************************************************************
** Use user-defined material UMAT subroutine for customized SDV outputs **************
**************************************************************************************
C
C       
      subroutine umat(stress,statev,ddsdde,sse,spd,scd,
     1 rpl,ddsddt,drplde,drpldt,
     2 stran,dstran,time,dtime,temp,dtemp,predef,dpred,cmname,
     3 ndi,nshr,ntens,nstatv,props,nprops,coords,drot,pnewdt,
     4 celent,dfgrd0,dfgrd1,noel,npt,layer,kspt,kstep,kinc)
C
      use kvisual
      include 'aba_param.inc'
C
      character*80 cmname
      dimension stress(ntens),statev(nstatv),
     1 ddsdde(ntens,ntens),
     2 ddsddt(ntens),drplde(ntens),
     3 stran(ntens),dstran(ntens),time(2),predef(1),dpred(1),
     4 props(nprops),coords(3),drot(3,3),dfgrd0(3,3),dfgrd1(3,3)
      !
      ! IMPORTANT: CHANGE nelem MANUALLY here ........................!
      !
      PARAMETER (maxDOF=2 , ndof=2 , ndim=2 ,ngp=4, nelem=4, nsdv=4)
      !
      !
      integer kelem
      
      stress = 0.0d0
      ddsdde = 0.0d0

      kelem=int(noel-nelem)
      ! Make sure that Kelem starts from 1 ----------------------------!
      
      do k1 = 1, nsdv
        statev(k1) = sigout(kelem,npt,k1)
      end do 
      
      return
      end 

C		
C
**************************************************************************************
** End *******************************************************************************
**************************************************************************************      